module.exports = {
  //Your Twitter credentials go in this file
    consumer_key: 'jjrFSskHTkQWJR6nakJcbP58s',
    consumer_secret: 'g4q4exUqRuitlBjI2j97V0DIaJIPSu7JKHMowNNKdNTSHqF4rz',
    access_token: '801557196437790720-5lTRVd5yk8lpbZPdhcX7i3EDPL9g9ID',
    access_token_secret: 'vcKJCCHOvWHgosmMpGrLqBpF4K7grecaTpmvPCoAXETr9'
};