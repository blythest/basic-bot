 module.exports = {
    Bucket: 'twitter-bot-text',
	Key: 'bots.txt',
	ContentType: 'text/plain',
	ACL: 'public-read'
};